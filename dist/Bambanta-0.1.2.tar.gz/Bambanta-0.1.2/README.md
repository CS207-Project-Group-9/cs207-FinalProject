[![Build Status](https://travis-ci.org/CS207-Project-Group-9/cs207-FinalProject.svg?branch=master)](https://travis-ci.org/CS207-Project-Group-9/cs207-FinalProject)

[![Coverage Status](https://coveralls.io/repos/github/CS207-Project-Group-9/cs207-FinalProject/badge.svg?branch=master)](https://coveralls.io/github/CS207-Project-Group-9/cs207-FinalProject?branch=master)

# Bambanta

CS207 Project Group 9:

Qiansha (Karina) Huang
Rong Liu
Rory Maizels


